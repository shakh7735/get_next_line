extern "C"
{
#define new tripouille
#include "get_next_line.h"
#undef new
}

#include <sys/wait.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include "sigsegv.hpp"
#include "check.hpp"
#include "gnl.hpp"

int iTest = 1;
int main(void)
{
	signal(SIGSEGV, sigsegv); int fd;
	title("[BUFFER_SIZE = " << BUFFER_SIZE << "]: " << ENDL)
	title("Invalid fd: ")
	fd = open("files/empty", O_RDWR);
	TEST(/* 1 */ gnl(1000,  NULL);
		 /* 2 */ gnl(-1,  NULL); close(fd);
		 /* 3 */ gnl(fd,  NULL);) cout << ENDL;

	title("files/empty: ")
	fd = open("files/empty", O_RDWR);
	TEST(/* 1 */ gnl(fd, NULL);
		 /* 2 */ gnl(fd, NULL);) cout << ENDL; close(fd);
	write(1, "\n", 1);
	return (0);
}